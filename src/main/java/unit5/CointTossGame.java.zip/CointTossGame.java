package unit5;

import java.util.Scanner;

public class CointTossGame {
    private int choice;
    private int points;

    public void setChoice(int choice) {
        this.choice = choice;
        this.points = 100;
    }

    public int num() {
        return (int) (Math.random() * (2 - 1 + 1) + 1);
    }

    public void print() {
        Scanner input = new Scanner(System.in);
        System.out.println(
                "1 - Head\n" +
                        "2 - Tail\n" +
                        "0 - Quit\n" +
                        "Enter your pick: ");
        int choice = input.nextInt();
        System.out.println("Your pick: " + choice);
    }

    public String face() {
        if (choice == 1) {
            return "Head";
        }
        if (choice == 2) {
            return "Tails";
        }
        return "0";
    }

    public String thing() {
        if (num() == 1) {
            return "Head";
        } else {
            return "Tails";
        }
    }

    public String win() {
        if (thing().equals(face())) {
            return "You Won!";
        }
        return "You lost!";
    }

    public void points() {
        if (thing().equals(face())) {
            points++;
        }
        points--;
    }


    public void writetoss() {
        print();
        while (true) {
            if (num() == choice) {
                System.out.println("Your pick " + face());
                System.out.println("Coin toss Result " + thing());
                System.out.println(win());
                System.out.println("Points: " + points);
            }
            if (choice == 0) {
                break;
            }
        }
        System.out.println("Thank you for playing...Bye");
    }
}

class test {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int e = input.nextInt();

        CointTossGame ct = new CointTossGame();

        ct.setChoice(e);

        ct.writetoss();
    }

}