package ujasjkb;


import java.util.Scanner;

public class example {
        public static void main(String[] args) {
            Scanner input = new Scanner(System.in);

            System.out.println("Jenis pizza apa yang kamu mau?");
            String jenis = input.next();
            System.out.println("Mau tambah topping apa?");
            String topping = input.next();
            System.out.println("Mau ada tambahan makanan tidak?");
            String tambahan = input.next();
            System.out.println("Kamu order pizza " + jenis + " dengan extra " + topping + " dan " + tambahan + " ekstra");
        }
    }

