package ujasjkb;

import java.util.Scanner;

public class iuaas {

    public String pizza(int p) {
        int pizza = p;
        if (pizza == 1) {
            return "pepperoni";
        } else if (pizza == 2) {
            return  "cheese";
        } else if (pizza == 3) {
            return "beef";
        } else
            System.out.println("Hey Choose a number between 1-3");
        return " ";
    }

    public String topping(int t){
    int topping = t;
            if (topping == 1) {
        return "tomato";
    } else if (topping == 2) {
        return  "sausage";
    } else if (topping == 3) {
        return "sauce";
    } else
            System.out.println("Hey Choose a number between 1-3");
            return"";
    }

    public String Side(int s){
        int side = s;
        if (side == 1) {
            return "fries";
        } else if (side == 2) {
            return "soda";
        } else if (side == 3) {
            return  "bread";
        } else
            System.out.println("Hey Choose a number between 1-3");
        return"";


    }
    }

    class test{
        public static void main(String[] args) {
            Scanner input = new Scanner(System.in);
            iuaas iu = new iuaas();

            System.out.println("What kind of pizza do you like? \n" +
                    "Please choose from 1-3");
            System.out.print("" +
                    "1. Pepperoni \n" +
                    "2. Cheese \n" +
                    "3. Beef \n" +
                    "Your choice: ");
            int p = input.nextInt();

            System.out.println("What kind of topping would you like? \n" +
                    "Please choose from 1-3");
            System.out.print("" +
                    "1. Tomato \n" +
                    "2. Sausage \n" +
                    "3. Sauce \n" +
                    "Your choice: ");
            int t = input.nextInt();

            System.out.println("What kind of side dish would you like? \n" +
                    "Please choose from 1-3");
            System.out.print("" +
                    "1. Fries \n" +
                    "2. Soda \n" +
                    "3. Bread \n" +
                    "Your choice: ");
            int s = input.nextInt();

            System.out.println("You chose a " + iu.pizza(p) + " pizza with extra " + iu.topping(t) + " and a " + iu.Side(s) + " for a side");

        }

    }